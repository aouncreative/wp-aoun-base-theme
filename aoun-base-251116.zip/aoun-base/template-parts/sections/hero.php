<?php
$args = wp_parse_args( $args ?? [], [
    'title'    => '',
    'subtitle' => '',
    'button'   => '',
    'url'      => '',
]);
?>

<section class="aoun-hero">
  <div class="aoun-hero__inner aoun-container">
    <?php if ( $args['title'] ) : ?>
      <h1 class="aoun-hero__title">
        <?php echo esc_html( $args['title'] ); ?>
      </h1>
    <?php endif; ?>

    <?php if ( $args['subtitle'] ) : ?>
      <p class="aoun-hero__subtitle">
        <?php echo esc_html( $args['subtitle'] ); ?>
      </p>
    <?php endif; ?>

    <?php if ( $args['button'] && $args['url'] ) : ?>
      <a class="aoun-hero__button" href="<?php echo esc_url( $args['url'] ); ?>">
        <?php echo esc_html( $args['button'] ); ?>
      </a>
    <?php endif; ?>
  </div>
</section>