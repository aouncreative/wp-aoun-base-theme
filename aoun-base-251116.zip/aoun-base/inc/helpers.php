<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Meta mit Default holen.
 */
function aoun_base_get_meta( $post_id, $key, $default = '' ) {
    $value = get_post_meta( $post_id, $key, true );
    return $value !== '' ? $value : $default;
}