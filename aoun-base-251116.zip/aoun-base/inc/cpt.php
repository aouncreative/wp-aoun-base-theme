<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Custom Post Types für dieses Projekt.
 * Für jeden Kunden nach Bedarf anpassen/erweitern.
 */
function aoun_base_register_cpts() {

    // Beispiel: Generischer Custom Post Type
    register_post_type( 'case', [
        'label'         => 'CPT',
        'public'        => true,
        'show_in_menu'  => true,
        'supports'      => [ 'title', 'editor', 'thumbnail' ],
        'has_archive'   => true,
        'rewrite'       => [ 'slug' => 'cpts' ], // Slug kannst du später noch anpassen
        'show_in_rest'  => false, // klassisch
        'menu_icon'     => 'dashicons-analytics',
    ] );

    // weitere CPTs hier ergänzen
}
add_action( 'init', 'aoun_base_register_cpts' );