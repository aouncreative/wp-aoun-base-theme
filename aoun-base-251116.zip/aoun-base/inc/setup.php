<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Theme-Basiskonfiguration
 */
function aoun_base_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );

    add_theme_support( 'html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ] );

    register_nav_menus( [
        'primary' => __( 'Hauptnavigation', 'aoun-base' ),
    ] );
}
add_action( 'after_setup_theme', 'aoun_base_setup' );

/**
 * Assets laden
 */
function aoun_base_enqueue_assets() {
    wp_enqueue_style(
        'aoun-base-app',
        AOUN_BASE_URI . '/assets/css/app.css',
        [],
        filemtime( AOUN_BASE_PATH . '/assets/css/app.css' )
    );

    wp_enqueue_script(
        'aoun-base-app',
        AOUN_BASE_URI . '/assets/js/app.js',
        [],
        filemtime( AOUN_BASE_PATH . '/assets/js/app.js' ),
        true
    );
}
add_action( 'wp_enqueue_scripts', 'aoun_base_enqueue_assets' );
