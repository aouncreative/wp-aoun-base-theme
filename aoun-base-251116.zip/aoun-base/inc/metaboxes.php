<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Metaboxen registrieren
 */
function aoun_base_add_meta_boxes() {

    // Hero-Bereich für Seiten (Startseite / Landing Pages)
    add_meta_box(
        'aoun_base_hero',
        'Hero Bereich',
        'aoun_base_render_hero_metabox',
        'page',
        'normal',
        'high'
    );

    // weitere Metaboxen hier registrieren
}
add_action( 'add_meta_boxes', 'aoun_base_add_meta_boxes' );

/**
 * Hero-Metabox rendern
 */
function aoun_base_render_hero_metabox( $post ) {
    wp_nonce_field( 'aoun_base_save_hero', 'aoun_base_hero_nonce' );

    $title    = get_post_meta( $post->ID, '_aoun_base_hero_title', true );
    $subtitle = get_post_meta( $post->ID, '_aoun_base_hero_subtitle', true );
    $button   = get_post_meta( $post->ID, '_aoun_base_hero_button_label', true );
    $url      = get_post_meta( $post->ID, '_aoun_base_hero_button_url', true );
    ?>
    <p>
        <label for="aoun_base_hero_title">Titel</label><br>
        <input type="text" id="aoun_base_hero_title" name="aoun_base_hero_title"
               value="<?php echo esc_attr( $title ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="aoun_base_hero_subtitle">Untertitel</label><br>
        <textarea id="aoun_base_hero_subtitle" name="aoun_base_hero_subtitle"
                  rows="3" style="width:100%;"><?php echo esc_textarea( $subtitle ); ?></textarea>
    </p>

    <p>
        <label for="aoun_base_hero_button_label">Button Label</label><br>
        <input type="text" id="aoun_base_hero_button_label" name="aoun_base_hero_button_label"
               value="<?php echo esc_attr( $button ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="aoun_base_hero_button_url">Button URL</label><br>
        <input type="url" id="aoun_base_hero_button_url" name="aoun_base_hero_button_url"
               value="<?php echo esc_attr( $url ); ?>" style="width:100%;">
    </p>
    <?php
}

/**
 * Hero-Metadaten speichern
 */
function aoun_base_save_hero_meta( $post_id ) {
    if ( ! isset( $_POST['aoun_base_hero_nonce'] ) ) {
        return;
    }
    if ( ! wp_verify_nonce( $_POST['aoun_base_hero_nonce'], 'aoun_base_save_hero' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $map = [
        'aoun_base_hero_title'         => '_aoun_base_hero_title',
        'aoun_base_hero_subtitle'      => '_aoun_base_hero_subtitle',
        'aoun_base_hero_button_label'  => '_aoun_base_hero_button_label',
        'aoun_base_hero_button_url'    => '_aoun_base_hero_button_url',
    ];

    foreach ( $map as $field => $meta_key ) {
        if ( isset( $_POST[ $field ] ) ) {
            $value = ( $field === 'aoun_base_hero_button_url' )
                ? esc_url_raw( $_POST[ $field ] )
                : sanitize_text_field( $_POST[ $field ] );

            update_post_meta( $post_id, $meta_key, $value );
        }
    }
}
add_action( 'save_post_page', 'aoun_base_save_hero_meta' );
