<footer class="aoun-footer">
  <div class="aoun-footer__inner aoun-container">
    <small>&copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?></small>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>