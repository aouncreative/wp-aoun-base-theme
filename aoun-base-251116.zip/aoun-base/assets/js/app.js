// AOUN Base – global JS (bewusst minimal)

document.addEventListener("DOMContentLoaded", () => {
  // Platzhalter für spätere Interaktionen
});
